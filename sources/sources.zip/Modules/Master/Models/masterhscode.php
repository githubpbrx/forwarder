<?php

namespace Modules\Master\Models;

use Illuminate\Database\Eloquent\Model;

class masterhscode extends Model
{
    protected $table = 'masterhscode';
    protected $primaryKey = 'id_hscode';
    protected $guard = [];
}
