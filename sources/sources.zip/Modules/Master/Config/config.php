<?php

return [
    'name' => 'Master'
];
