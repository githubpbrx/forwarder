<?php

namespace Modules\System\Models;

use Illuminate\Database\Eloquent\Model;

class modelcoc extends Model
{
    protected $table = 'coc';
    protected $primaryKey = 'id_coc';
    protected $guarded = [];
}
