<?php

namespace Modules\System\Models;

use Illuminate\Database\Eloquent\Model;

class masterforwarder extends Model
{
    protected $table = 'masterforwarder';
    protected $primaryKey = 'id';
    protected $guarded = [];
}
