<?php

namespace Modules\System\Models;

use Illuminate\Database\Eloquent\Model;

class modelkyc extends Model
{
    protected $table = 'kyc';
    protected $primaryKey = 'id_kyc';
    protected $guarded = [];
}
