<?php

namespace Modules\Transaksi\Models;

use Illuminate\Database\Eloquent\Model;

class masterroute extends Model
{
    protected $table = 'masterroute';
    protected $primaryKey = 'id_route';
    protected $guard = [];
}
