<?php

namespace Modules\Transaksi\Models;

use Illuminate\Database\Eloquent\Model;

class masterhscode extends Model
{
    protected $table = 'masterhscode';
    protected $primaryKey = 'id_hscode';
    protected $guard = [];
}
