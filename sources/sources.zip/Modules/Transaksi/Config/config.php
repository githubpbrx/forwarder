<?php

return [
    'name' => 'Transaksi'
];
