<?php

namespace Modules\Report\Models;

use Illuminate\Database\Eloquent\Model;

class modelapproval extends Model
{
    protected $table = 'approval';
    protected $primaryKey = 'id_approval';
    protected $guarded = [];
}
